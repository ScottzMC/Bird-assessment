<?php

  class Email extends CI_Controller{

    public function index(){
      $submit = $this->input->post('send');

      if(isset($submit)){
        $fullname = $this->input->post('fullname');
        $telephone = $this->input->post('telephone');
        $email = $this->input->post('email');
        $message = $this->input->post('message');

        $subject = "Email Notification";
        $body = "Please kindly find attached the submitted info below:
        Fullname - $fullname,
        Telephone Number - $telephone,
        Message - $message";
        $date = date('Y-m-d H:i:s');

        $config = Array(
       'protocol' => 'smtp',
       'smtp_host' => 'smtp.gadgetshopdeal.com', // change it to host such as - smtp.assessment.birdmarketing.co.uk
       'smtp_port' => 25,
       'smtp_user' => 'test@gadgetshopdeal.com', // change it to hosting email such as - test@assessment.birdmarketing.co.uk
       'smtp_pass' => '@Testing100', // change it to account email password
       'mailtype' => 'html',
       'charset' => 'iso-8859-1',
       'wordwrap' => TRUE
       );

       $this->load->library('email', $config);
       $this->email->from('test@gadgetshopdeal.com', 'Gadget Shop Deal'); // it receives two parameters such as the company sending the email and the name they would be addressed as
                                              // 'test@assessment.birdmarketing.co.uk', 'Assessment Bird Marketing'
       $this->email->to("test@gadgetshopdeal.com");
       //$this->email->cc("testcc@domainname.com");
       $this->email->subject("$subject");
       $this->email->message("$body");

        $data_array = array(
          'fullname' => $fullname,
          'telephone' => $telephone,
          'email' => $email,
          'message' => $message
        );

        $insert_data = $this->Data_model->send($data_array);

        if($insert_data && $this->email->send()){ ?>
          <script>
            alert('Message sent');
            window.location.reload();
          </script>
  <?php }else{ ?>
          <script>
            alert('Message failed');
            window.location.reload();
          </script>
  <?php }
      }else{
        $this->load->view('email_modal');
      }
    }
  }

?>
