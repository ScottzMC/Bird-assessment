<?php

  class Data_model extends CI_Model{

    public function send($data){
      $query = $this->db->insert('email', $data);
      return $query;
    }
  }

?>
